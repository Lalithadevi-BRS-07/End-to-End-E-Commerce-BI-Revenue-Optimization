Run python src/analysis.py to generate analysis CSVs and PNG charts in this folder.
