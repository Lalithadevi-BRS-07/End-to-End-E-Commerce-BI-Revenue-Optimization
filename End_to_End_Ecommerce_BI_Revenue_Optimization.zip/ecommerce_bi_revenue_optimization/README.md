# End-to-End E-Commerce Business Intelligence & Revenue Optimization

## Project overview
This advanced portfolio project simulates an e-commerce analytics engagement. It combines relational data modelling, SQL business analysis, Python exploratory analysis and a Power BI dashboard design.

**Important data note:** The included CSV files are synthetic, generated for learning and portfolio development. They are not real customer records and are not a live company dataset. State codes and business patterns are illustrative. Clearly label the dataset as synthetic in any public portfolio.

## Business questions
- Which months, categories, products and acquisition channels drive revenue and contribution profit?
- Which customers are repeat purchasers and how can customers be segmented using RFM?
- How do discounts relate to contribution profit?
- Which regions contribute the most revenue?
- What is the distribution of delivery times and order statuses?

## Project structure
- `data/`: four linked CSV tables.
- `sql/01_schema.sql`: PostgreSQL table definitions.
- `sql/02_business_analysis_queries.sql`: example business analysis queries.
- `src/analysis.py`: Python analysis, quality checks, RFM, CSV outputs and charts.
- `src/requirements.txt`: Python dependencies.
- `powerbi/DAX_measures.txt`: suggested measures, relationships and report pages.
- `reports/`: generated analysis outputs after running the script.

## Data model
`customers` (1) -> `orders` (many) -> `order_items` (many) <- `products` (1).

## Run the Python analysis
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r src/requirements.txt
python src/analysis.py
```

## Load into PostgreSQL
1. Create a database, e.g. `ecommerce_bi`.
2. Run `sql/01_schema.sql`.
3. Import each CSV into its matching table using pgAdmin Import/Export or `\copy`.
4. Run selected queries from `sql/02_business_analysis_queries.sql`.

Example `psql` import commands (run from the project root):
```sql
\copy customers FROM 'data/customers.csv' WITH (FORMAT csv, HEADER true);
\copy products FROM 'data/products.csv' WITH (FORMAT csv, HEADER true);
\copy orders FROM 'data/orders.csv' WITH (FORMAT csv, HEADER true);
\copy order_items FROM 'data/order_items.csv' WITH (FORMAT csv, HEADER true);
```
If your database is hosted remotely, use the appropriate secure import method. Do not commit credentials.

## Build the Power BI report
1. Get Data -> Text/CSV and load the four CSV files.
2. Create the relationships listed in `powerbi/DAX_measures.txt`.
3. Create a calendar/date table and mark it as a date table.
4. Add the DAX measures and create the five suggested report pages.
5. Validate totals against the SQL results before publishing.

## Suggested advanced extensions
- Add a proper star schema with fact and dimension tables.
- Create a monthly cohort retention matrix.
- Perform market basket analysis with association rules.
- Compare forecasting models using a time-based holdout and MAE/RMSE/MAPE.
- Add discount elasticity analysis; distinguish correlation from causal impact.
- Add automated data quality tests and a reproducible pipeline.

## Portfolio checklist
- [ ] Explain the business problem and assumptions.
- [ ] Include screenshots of each dashboard page.
- [ ] Include SQL scripts and Python source.
- [ ] Add a short executive summary with findings based on your run.
- [ ] State clearly that the included dataset is synthetic.
- [ ] Do not invent business impact or performance improvements.

## Limitations
This is a project starter kit with reproducible synthetic data. It is not a production-grade data warehouse or a validated revenue forecasting system. Extend and test it before describing it as production-ready.
