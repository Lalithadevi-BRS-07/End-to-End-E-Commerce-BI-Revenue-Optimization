-- 1. Executive KPIs (delivered orders only)
SELECT COUNT(DISTINCT o.order_id) AS delivered_orders,
       COUNT(DISTINCT o.customer_id) AS purchasing_customers,
       SUM(i.gross_sales) AS gross_revenue,
       SUM(i.gross_sales - i.product_cost + i.shipping_revenue - i.shipping_cost) AS contribution_profit,
       SUM(i.gross_sales) / NULLIF(COUNT(DISTINCT o.order_id),0) AS average_order_value
FROM orders o JOIN order_items i USING(order_id)
WHERE o.order_status='delivered';

-- 2. Monthly revenue and profit
SELECT DATE_TRUNC('month', o.order_date)::date AS month,
       SUM(i.gross_sales) AS revenue,
       SUM(i.gross_sales-i.product_cost+i.shipping_revenue-i.shipping_cost) AS profit
FROM orders o JOIN order_items i USING(order_id)
WHERE o.order_status='delivered'
GROUP BY 1 ORDER BY 1;

-- 3. Category profitability
SELECT p.category, SUM(i.gross_sales) revenue,
       SUM(i.gross_sales-i.product_cost+i.shipping_revenue-i.shipping_cost) profit,
       ROUND(100.0*SUM(i.gross_sales-i.product_cost+i.shipping_revenue-i.shipping_cost)
             / NULLIF(SUM(i.gross_sales),0),2) AS profit_margin_pct
FROM order_items i JOIN products p USING(product_id)
JOIN orders o USING(order_id)
WHERE o.order_status='delivered'
GROUP BY p.category ORDER BY profit DESC;

-- 4. Top products by revenue
SELECT p.product_id,p.category,SUM(i.quantity) units_sold,SUM(i.gross_sales) revenue
FROM order_items i JOIN products p USING(product_id)
JOIN orders o USING(order_id)
WHERE o.order_status='delivered'
GROUP BY p.product_id,p.category ORDER BY revenue DESC LIMIT 15;

-- 5. Customer RFM base table
WITH customer_orders AS (
 SELECT o.customer_id,o.order_id,o.order_date,SUM(i.gross_sales) order_value
 FROM orders o JOIN order_items i USING(order_id)
 WHERE o.order_status='delivered'
 GROUP BY o.customer_id,o.order_id,o.order_date
)
SELECT customer_id,
       MAX(order_date) AS last_order_date,
       COUNT(DISTINCT order_id) AS frequency,
       SUM(order_value) AS monetary_value
FROM customer_orders GROUP BY customer_id;

-- 6. Repeat purchase rate
WITH c AS (
 SELECT customer_id,COUNT(DISTINCT order_id) n_orders
 FROM orders WHERE order_status='delivered' GROUP BY customer_id
)
SELECT COUNT(*) FILTER(WHERE n_orders>1) AS repeat_customers,
       COUNT(*) AS customers,
       ROUND(100.0*COUNT(*) FILTER(WHERE n_orders>1)/NULLIF(COUNT(*),0),2) repeat_rate_pct
FROM c;

-- 7. Discount versus margin
SELECT CASE WHEN discount_rate=0 THEN '0%'
            WHEN discount_rate<=0.05 THEN '1-5%'
            WHEN discount_rate<=0.10 THEN '6-10%'
            WHEN discount_rate<=0.15 THEN '11-15%' ELSE '16-20%' END discount_band,
       SUM(gross_sales) revenue,
       SUM(gross_sales-product_cost+shipping_revenue-shipping_cost) profit
FROM order_items i JOIN orders o USING(order_id)
WHERE o.order_status='delivered'
GROUP BY 1 ORDER BY 1;

-- 8. Channel performance
SELECT acquisition_channel,COUNT(DISTINCT o.order_id) orders,
       SUM(i.gross_sales) revenue,
       SUM(i.gross_sales-i.product_cost+i.shipping_revenue-i.shipping_cost) profit
FROM orders o JOIN order_items i USING(order_id)
WHERE o.order_status='delivered'
GROUP BY acquisition_channel ORDER BY revenue DESC;

-- 9. State performance
SELECT c.customer_state,COUNT(DISTINCT o.order_id) orders,SUM(i.gross_sales) revenue
FROM orders o JOIN customers c USING(customer_id)
JOIN order_items i USING(order_id)
WHERE o.order_status='delivered'
GROUP BY c.customer_state ORDER BY revenue DESC;

-- 10. Delivery performance
SELECT CASE WHEN delivery_days<=3 THEN '1-3 days'
            WHEN delivery_days<=7 THEN '4-7 days'
            WHEN delivery_days<=14 THEN '8-14 days' ELSE '15+ days' END delivery_bucket,
       COUNT(*) orders,AVG(delivery_days) avg_delivery_days
FROM orders WHERE order_status='delivered'
GROUP BY 1 ORDER BY 1;
