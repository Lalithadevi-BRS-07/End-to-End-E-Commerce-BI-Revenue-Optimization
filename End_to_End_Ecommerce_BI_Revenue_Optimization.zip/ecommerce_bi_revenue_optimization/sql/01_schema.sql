CREATE TABLE customers (
  customer_id VARCHAR(10) PRIMARY KEY,
  customer_state VARCHAR(2),
  signup_date DATE
);
CREATE TABLE products (
  product_id VARCHAR(10) PRIMARY KEY,
  category VARCHAR(50),
  unit_cost DECIMAL(12,2),
  list_price DECIMAL(12,2)
);
CREATE TABLE orders (
  order_id VARCHAR(12) PRIMARY KEY,
  customer_id VARCHAR(10) REFERENCES customers(customer_id),
  order_date DATE,
  order_status VARCHAR(20),
  payment_type VARCHAR(30),
  delivery_days INTEGER,
  acquisition_channel VARCHAR(40),
  device VARCHAR(20),
  order_month VARCHAR(7)
);
CREATE TABLE order_items (
  order_id VARCHAR(12) REFERENCES orders(order_id),
  product_id VARCHAR(10) REFERENCES products(product_id),
  quantity INTEGER,
  unit_price DECIMAL(12,2),
  discount_rate DECIMAL(5,4),
  gross_sales DECIMAL(12,2),
  unit_cost DECIMAL(12,2),
  product_cost DECIMAL(12,2),
  shipping_revenue DECIMAL(12,2),
  shipping_cost DECIMAL(12,2)
);
