from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "reports"
OUT.mkdir(exist_ok=True)

customers = pd.read_csv(DATA/"customers.csv", parse_dates=["signup_date"])
products = pd.read_csv(DATA/"products.csv")
orders = pd.read_csv(DATA/"orders.csv", parse_dates=["order_date"])
items = pd.read_csv(DATA/"order_items.csv")

df = (items.merge(orders, on="order_id", validate="many_to_one")
          .merge(products, on="product_id", validate="many_to_one")
          .merge(customers, on="customer_id", validate="many_to_one"))
df = df[df.order_status.eq("delivered")].copy()
df["revenue"] = df["quantity"] * df["unit_price"]
df["profit"] = df["revenue"] - df["product_cost"] + df["shipping_revenue"] - df["shipping_cost"]
df["month"] = df.order_date.dt.to_period("M").astype(str)

# Data quality checks
quality = pd.DataFrame({
    "check": ["duplicate_order_ids", "missing_customer_id", "negative_revenue", "missing_product_cost"],
    "count": [
        orders.order_id.duplicated().sum(),
        orders.customer_id.isna().sum(),
        (df.revenue < 0).sum(),
        df.product_cost.isna().sum()
    ]
})
quality.to_csv(OUT/"data_quality_checks.csv", index=False)

# Monthly performance
monthly = df.groupby("month", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum"),
    units=("quantity","sum"), orders=("order_id","nunique"))
monthly["profit_margin_pct"] = 100*monthly.profit/monthly.revenue
monthly.to_csv(OUT/"monthly_performance.csv", index=False)

# Category performance
category = df.groupby("category", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum"), units=("quantity","sum"))
category["profit_margin_pct"] = 100*category.profit/category.revenue
category.sort_values("profit", ascending=False).to_csv(OUT/"category_performance.csv", index=False)

# Customer-level RFM (reference date is day after last observed order)
cust_order = df.groupby(["customer_id","order_id","order_date"], as_index=False).revenue.sum()
reference_date = cust_order.order_date.max() + pd.Timedelta(days=1)
rfm = cust_order.groupby("customer_id").agg(
    recency=("order_date", lambda s: (reference_date-s.max()).days),
    frequency=("order_id","nunique"),
    monetary=("revenue","sum")).reset_index()
for col in ["recency","frequency","monetary"]:
    ascending = (col == "recency")
    rfm[col+"_score"] = pd.qcut(rfm[col].rank(method="first"), 5, labels=[1,2,3,4,5]).astype(int)
    if ascending:
        rfm[col+"_score"] = 6-rfm[col+"_score"]
rfm["rfm_score"] = rfm[["recency_score","frequency_score","monetary_score"]].astype(str).agg("".join, axis=1)
rfm.to_csv(OUT/"customer_rfm.csv", index=False)

# Channel performance
channel = df.groupby("acquisition_channel", as_index=False).agg(
    revenue=("revenue","sum"), profit=("profit","sum"), orders=("order_id","nunique"))
channel.to_csv(OUT/"channel_performance.csv", index=False)

# Save plots
plt.figure(figsize=(11,5))
plt.plot(monthly["month"], monthly["revenue"], marker="o", label="Revenue")
plt.xticks(rotation=60, ha="right")
plt.title("Monthly Revenue Trend")
plt.tight_layout()
plt.savefig(OUT/"monthly_revenue.png", dpi=150)
plt.close()

plt.figure(figsize=(9,5))
cat = category.sort_values("profit", ascending=True)
plt.barh(cat["category"], cat["profit"])
plt.title("Contribution Profit by Category")
plt.tight_layout()
plt.savefig(OUT/"category_profit.png", dpi=150)
plt.close()

print("Analysis complete. Outputs saved in reports/.")
print(f"Delivered revenue: {df.revenue.sum():,.2f}")
print(f"Contribution profit: {df.profit.sum():,.2f}")
print(f"Delivered orders: {df.order_id.nunique():,}")
